#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    // Verifica che sia stato fornito un argomento

    // Converte l'argomento da stringa a numero intero
    int i;
    int s=0;
    for(i=1;i<argc;i++){
        s=s+atoi(argv[i]);
    }
    // Restituisce il numero come codice di uscita
    return s;
}