#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    // Verifica che sia stato fornito un argomento
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <numero>\n", argv[0]);
        return EXIT_FAILURE;
    }

    // Converte l'argomento da stringa a numero intero
    int numero = atoi(argv[1]);

    // Stampa il numero inserito
    printf("Il numero inserito e': %d\n", numero);

    // Restituisce il numero come codice di uscita
    return numero;
}