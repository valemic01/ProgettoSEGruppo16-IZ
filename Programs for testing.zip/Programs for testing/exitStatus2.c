#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    // Verifica che sia stato fornito un argomento
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <numero>\n", argv[0]);
        return EXIT_FAILURE;
    }

    // Converte l'argomento da stringa a numero intero
    int numero1 = atoi(argv[1]);
    int numero2 = atoi(argv[2]);

    // Restituisce il numero come codice di uscita
    return numero1+numero2;
}