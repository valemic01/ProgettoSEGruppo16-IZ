# Verifica che sia stato passato almeno un argomento
if ($args.Count -eq 0) {
    Write-Host "Usage: $($MyInvocation.MyCommand.Name) <number>"
    exit 1
}

# Prende il primo argomento dalla linea di comando
$number = $args[0]

# Restituisce il numero passato come argomento
Write-Host "Il numero passato è: $number"

# Restituisce l'exit status uguale al numero passato
exit $number